﻿namespace ApiEscola.Data.Context
{
    public class SQLServer
    {
    }
}
